-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 30, 2023 at 11:10 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `php full project`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `id` int(100) NOT NULL,
  `course` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `course`) VALUES
(1, 'webdesign'),
(23, 'webdesign'),
(24, 'adssdf'),
(25, 'sdfsdf'),
(26, 'sdfdfsdf'),
(27, 'sfsfd'),
(28, 'sdfsdf'),
(29, 'sdsdf'),
(30, 'graphic_desioner'),
(31, '');

-- --------------------------------------------------------

--
-- Table structure for table `change _logo`
--

CREATE TABLE `change _logo` (
  `id` int(250) NOT NULL,
  `logo` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `change _logo`
--

INSERT INTO `change _logo` (`id`, `logo`) VALUES
(1, 'profile_picture.png');

-- --------------------------------------------------------

--
-- Table structure for table `student_admission_data`
--

CREATE TABLE `student_admission_data` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `father name` varchar(100) NOT NULL,
  `mother name` varchar(100) NOT NULL,
  `date of birth` varchar(100) NOT NULL,
  `religion` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `job title` varchar(100) NOT NULL,
  `blood group` varchar(100) NOT NULL,
  `nid / birth certificate` varchar(100) NOT NULL,
  `coursetype` varchar(100) NOT NULL,
  `phone number` varchar(100) NOT NULL,
  `guardian number` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `session` varchar(100) NOT NULL,
  `course` varchar(100) NOT NULL,
  `register type` varchar(100) NOT NULL,
  `total fee` varchar(100) NOT NULL,
  `register time` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_admission_data`
--

INSERT INTO `student_admission_data` (`id`, `name`, `father name`, `mother name`, `date of birth`, `religion`, `gender`, `job title`, `blood group`, `nid / birth certificate`, `coursetype`, `phone number`, `guardian number`, `email`, `address`, `session`, `course`, `register type`, `total fee`, `register time`, `status`, `photo`) VALUES
(5, 'mdalif', 'mdfaruk', 'halimabegum', '2023-11-14', 'Islam', 'Male', 'Student', 'error', 'Offline', '232323', '01881162313', '01913005206', 'mdalif5218@gmail.com', 'Old Bus Stand , Madaripur', 'January - March', 'Computer Office Application', 'Government', '4544', '2023-11-14 01:03:17pm', 'Active', 'avator.png'),
(6, 'kobita', 'abul kasum', 'fulljan', '2003-01-01', 'Islam', 'Female', 'Student', 'B-', 'Offline', '202023', '010954496280', '02323630054', 'kakoli@gmial.com', 'madaripur', 'January - March', 'Computer Office Application', 'Government', '15000', '2023-12-20 10:44:15am', 'Active', ''),
(7, 'kakoli islam', 'abul kasum kahan', 'full jan begum', '2003-01-01', 'Islam', 'Female', 'Student', 'B-', 'Offline', '202320', '010954496280', '02323630054', 'kakoli@gmial.com', 'madaripur', 'January - March', 'webdesign', 'Government', '15000', '2023-12-20 04:37:07pm', 'Active', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_register_data`
--

CREATE TABLE `user_register_data` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `father name` varchar(100) NOT NULL,
  `mother name` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `register time` text NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_register_data`
--

INSERT INTO `user_register_data` (`id`, `name`, `username`, `father name`, `mother name`, `phone`, `email`, `address`, `password`, `register time`, `status`) VALUES
(1, 'MD Alif', 'mdalif5218', 'Md Faruk Matabber', 'Halima Begum', '01881162313', 'webcoderalif5218@gmail.com', 'Old Bus Stand , Madaripur', 'fe32349a7d9ff6bbbfbb6e41c51ee991', '2023-11-14 10:21:00am', 'Active'),
(2, 'bristy01', 'bristyislam', 'abul kasum', 'fulljan', '01954496280', 'kakoli@gmial.com', 'madaripur', '25f9e794323b453885f5181f1b624d0b', '2023-12-02 02:59:43pm', 'Active'),
(3, 'sarmin', 'sarmin', 'mosarof', 'ranu bagom', '01954496280', 'sarmin@gmail.com', 'madaripur', '25f9e794323b453885f5181f1b624d0b', '2023-12-13 03:45:09pm', 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `change _logo`
--
ALTER TABLE `change _logo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_admission_data`
--
ALTER TABLE `student_admission_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_register_data`
--
ALTER TABLE `user_register_data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about`
--
ALTER TABLE `about`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `change _logo`
--
ALTER TABLE `change _logo`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student_admission_data`
--
ALTER TABLE `student_admission_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user_register_data`
--
ALTER TABLE `user_register_data`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
