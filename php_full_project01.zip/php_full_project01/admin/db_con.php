<?php 
$db_con = mysqli_connect("localhost" , "root" , "" , "php full project");
?>