<?php
require("db_con.php");


$username = $_SESSION['user_name'];
$username_data_select = mysqli_query($db_con, "SELECT * FROM `user_register_data` WHERE `username`= '$username'");
$username_data_fetch = mysqli_fetch_assoc($username_data_select);


if(isset($_POST['change_pass'])){
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    $input_error = array();
    if(empty($old_password)){
        $input_error['old_password'] = 'old password is required !';
    }
    if(empty($new_password)){
        $input_error['new_password'] = 'new password is required !';
    }
    if(empty($confirm_password)){
        $input_error['confirm_password'] = 'confirm_password is required !';
    }

     if(count($input_error) ==0){
        $md5old_password = md5($old_password);
        if($md5old_password == $username_data_fetch['password']){
            if($new_password == $confirm_password){
                $password_update = mysqli_query($db_con,"UPDATE `user_register_data` SET `password`='[value-9]' WHERE `username`= '$username'");
                if($password_update){
                    echo '
                    <script>
                    alert("successfully update your  password");
                    </script>
                    ';
                }else{
                    echo '
                    <script>
                    alert("Unsuccessfully update your  password");
                    </script>
                    ';
                }
            }else{
                $input_error['old_password'] = 'confirm_password is not match !';
            }

        }else{
            $input_error['old_password'] = 'old password is wrong !';
        }

     }
}

?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>
<div class="dasboard">
<h1><i class="fa-solid fa-dollar-sign  px-2" style="font-size:35px"></i>Change Password <small> Statistics Overview</small></h1>
<div class="p-2" style="background:#f5f5f5;"><a href="admin_index.php?page=admin_dashboard"><i class="fa-solid fa-gauge"></i>Dashboard    <i class="fa-solid fa-people-group px-2" style="font-size:18px;"></i>Chnge Password</a></div>
</div>

<form action="" method="post" style="margin-top:20px;">
  <div class="col-sm-12">
    <div class="row">
    <!-- start -->
        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-xs-12">
            <div class="mb-1">
                <label for="old_password" class="form-label">Old Password<small style="color:#65BDB6"></small>
                <input type="password" class="form-control" name="old_password" value="<?php if(isset($old_password)){echo $old_password;}?>">
                <label class="text-danger"><?php if(isset($input_error['old_password'])){
                    echo $input_error['old_password'];}?>
                    </label>
            </div>
        </div>
        
    <!-- end -->
    </div>
  </div>

  <div class="col-sm-12">
    <div class="row">
    <!-- start -->
        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-xs-12">
            <div class="mb-1">
                <label for="new_password" class="form-label">New Password<small style="color:#65BDB6"></small>
                <input type="password" class="form-control" name="new_password" value="<?php if(isset($new_password)){echo $new_password;}?>">
                <label class="text-danger"><?php if(isset($input_error['new_password'])){
                    echo $input_error['new_password'];}?>
                </label>
            </div>
        </div>
    <!-- end -->
    </div>
  </div>

  <div class="col-sm-12">
    <div class="row">
    <!-- start -->
        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-xs-12">
            <div class="mb-1">
                <label for="confirm_password" class="form-label">Confirm Password<small style="color:#65BDB6"></small>
                <input type="password" class="form-control" name="confirm_password" value="<?php if(isset($confirm_password)){echo $confirm_password;}?>">
                <label class="text-danger"><?php if(isset($input_error['confirm_password'])){
                    echo $input_error['confirm_password'];}?></label>
            </div>
        </div>
    <!-- end -->
    </div>
  </div>
  <br/>
  <!-- submit btn start -->
  <div class="ad_btn">
    <input type="submit" value="Change Password" class="submit_btn" name="=change_pass" style="padding:5px 20px; background-color:#13A89E; border:none; coloe:white; " >

  </div>
    </form>
<script src="js/script.js"></script>





</body>
</html>