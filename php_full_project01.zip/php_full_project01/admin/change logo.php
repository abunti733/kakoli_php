<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>
    <div class="dasboard">
        <h1><i class="fa-solid fa-dollar-sign  px-2" style="font-size:35px"></i>Change Password <small> Statistics Overview</small></h1>
        <div class="p-2" style="background:#f5f5f5;"><a href="admin_index.php?page=admin_dashboard"><i class="fa-solid fa-gauge"></i>Dashboard    <i class="fa-solid fa-people-group px-2" style="font-size:18px;"></i>Chnge Password</a></div>
        </div>

        <?php 
        $student_admin_select=mysqli_query($db_con,"SELECT * FROM `change _logo` WHERE `id`='1'");
$student_admin_data=mysqli_fetch_assoc($student_admin_select);
	if(isset($_POST['photo_update'])){
		$student_photo=$_FILES['photo']['name'];
		  $photo_tmp=$_FILES['photo']['tmp_name'];
		$photo_update=mysqli_query($db_con,"UPDATE `change _logo` SET `logo`='$student_photo' WHERE `id`='1'");
		if($photo_update){
		  move_uploaded_file($photo_tmp,'images/'.$student_photo);
		  echo "<script>
		  alert('Your photo successfully updated!');
		</script>";
		$student_photo=false;
		}
		else{
		  echo "<script>
		  alert('Photo update failed!');
		</script>";
		}
		
	  }
	
	?>
<form action="" method="POST" enctype="multipart/form-data">
    <img class="img-thumbnail" style="width:220px;height:220px;" src="images/<?=$student_admin_data['logo'];?>" alt=""><br>
    <label for="photo" class="form-label">Profile Picture</label>
    <input type="file" class="form-control" name="photo" id="photo" required style="width:30%;" >
    <br>
    <button type="submit" name="photo_update"  class="btn btn-primary">Change Profile</button>
</form>

        <script src="js/script.js"></script>
</body>
</html>